# SYNCHRONIZE THIS FOLDER WITH THE FRONTEND

⚠️ This folder share core information with the frontend (validation schemas, constants, etc.).
Anything changed in this folder should be synchronize with the shared_with_backend folder in the frontend. ⚠️

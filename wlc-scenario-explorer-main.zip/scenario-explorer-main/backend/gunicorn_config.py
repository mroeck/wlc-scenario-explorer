"""used to get info about current os"""

import os


workers = int(os.environ.get("GUNICORN_PROCESSES", "2"))

threads = int(os.environ.get("GUNICORN_THREADS", "4"))

bind = os.environ.get("GUNICORN_BIND", "0.0.0.0:8081")


FORWARDED_ALLOW_IPS = "*"


secure_scheme_headers = {"X-Forwarded-Proto": "https"}

loglevel = os.environ.get("GUNICORN_LOG_LEVEL", "INFO")

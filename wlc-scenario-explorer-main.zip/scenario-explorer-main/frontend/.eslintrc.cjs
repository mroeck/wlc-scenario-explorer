module.exports = {
  root: true,
  env: { browser: true, es2020: true },
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/strict-type-checked",
    "plugin:react-hooks/recommended",
    "plugin:react/recommended",
    "plugin:@tanstack/eslint-plugin-query/recommended",
    "plugin:tailwindcss/recommended",
    "plugin:prettier/recommended",
  ],
  overrides: [
    {
      files: ["**/*.{ts,tsx}"],
      extends: ["plugin:@eslint-react/recommended-legacy"],
    },
  ],
  ignorePatterns: ["dist", ".eslintrc.cjs", "./*.ts"],
  parser: "@typescript-eslint/parser",
  parserOptions: {
    project: "./tsconfig.eslint.json",
  },
  plugins: [
    "react-refresh",
    "@typescript-eslint",
    "@eslint-react/eslint-plugin",
  ],
  rules: {
    "@typescript-eslint/restrict-template-expressions": ["error", { "allowNumber": true }],
    "react/no-unescaped-entities": "off",
    "react/prop-types": "off",
    "react/react-in-jsx-scope": "off",
    "@typescript-eslint/no-non-null-assertion": "off",
    "react-refresh/only-export-components": [
      "warn",
      { allowConstantExport: true },
    ],
    "@typescript-eslint/consistent-type-imports": [
      "warn",
      {
        prefer: "type-imports",
        fixStyle: "inline-type-imports",
      },
    ],
    "@typescript-eslint/no-unused-vars": [
      "error",
      {
        argsIgnorePattern: "^_",
      },
    ],
  },
  settings: {
    react: {
      version: "detect",
    },
    tailwindcss: {
      callees: ["classnames", "clsx", "ctl", "cn"],
    },
  },
};

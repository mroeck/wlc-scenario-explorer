export const HIGHLIGHT_OPACITY = 0.1;

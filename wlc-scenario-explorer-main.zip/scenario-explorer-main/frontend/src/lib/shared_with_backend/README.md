# SYNCHRONIZE THIS FOLDER WITH THE BACKEND

⚠️ This folder share core information with the backend (validation schemas, constants, etc.).
Anything changed in this folder should be synchronize with the shared_with_frontend folder in the backend. ⚠️

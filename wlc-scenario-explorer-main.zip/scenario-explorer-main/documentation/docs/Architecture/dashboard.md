# Dashboard



Here is a simplified diagram of how the dashboard page work:

![1728984015165](image/dashboard/1728984015165.png)

:::warning
We don't get the minmax from backend anymore, the frontend handles it.
:::
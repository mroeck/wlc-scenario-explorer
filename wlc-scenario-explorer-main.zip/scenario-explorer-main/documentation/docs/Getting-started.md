---
sidebar_position: 1
---

# Getting started

Checkout the readme.md at the root for the repository!
cd ../frontend
npm install -g pnpm@9.4.0
pnpm install
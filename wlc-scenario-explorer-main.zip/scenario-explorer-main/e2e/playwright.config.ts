import { STORAGE_KEYS } from "@/lib/constants";
import { defineConfig, devices } from "@playwright/test";
import { env } from "@tests/env";

export default defineConfig({
  testDir: "./tests",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [["html", { open: process.env.CI ? "never" : "on-failure" }]],
  use: {
    baseURL: env.BASE_URL,
    trace: "on-first-retry",
    storageState: {
      origins: [
        {
          localStorage: [
            { name: STORAGE_KEYS.isDisclaimerAccepted, value: "true" },
            { name: STORAGE_KEYS.isDividedByDisclaimerAccepted, value: "true" },
          ],
          origin: env.BASE_URL,
        },
      ],
      cookies: [],
    },
  },
  expect: {
    toHaveScreenshot: {
      maxDiffPixelRatio: 0.02,
    },
  },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
    {
      name: "Mobile Chrome",
      use: { ...devices["Pixel 5"] },
    },
  ],

  webServer: process.env.CI
    ? undefined
    : [
        {
          command:
            "cd ../frontend && VITE_NODE_ENV=test VITE_API_URL='http://localhost:8081' npm run build && npm run preview",
          url: "http://localhost:3001/health",
          reuseExistingServer: true,
          timeout: 30 * 1000,
        },
        {
          command: "cd ../backend && DATA_PATH=../data poetry run task preview",
          url: "http://localhost:8081/health",
          reuseExistingServer: true,
          timeout: 30 * 1000,
        },
      ],
});

import type { PredefinedScenario } from "@/lib/shared_with_backend/constants";

export type ScenarioOption = PredefinedScenario;

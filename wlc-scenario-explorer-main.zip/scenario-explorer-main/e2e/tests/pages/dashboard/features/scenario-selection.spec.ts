import {
  ROUTES,
  DISPLAY_SELECT_TESTID,
  SCENARIO_B_MENU_TESTID,
  FOR_SCENARIOS_TESTID,
  RESET_LABEL,
  MOBILE_SETTINGS_BUTTON,
  SCENARIO_TO_ACRONYM,
  DEFAULT_SCENARIO,
} from "@/lib/constants";
import { SCENARIOS_OPTIONS } from "@/lib/shared_with_backend/constants";
import { test, expect } from "@playwright/test";

test.describe("scenario selection", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(ROUTES.DASHBOARD + "?animation=false");
  });

  test("selecting a scenario update the display menu", async ({
    page,
    isMobile,
  }) => {
    const mobileSettings = page
      .locator("button")
      .filter({ hasText: MOBILE_SETTINGS_BUTTON });
    const scenarioA = DEFAULT_SCENARIO;
    const scenarioB = SCENARIOS_OPTIONS[2];
    const acronymA = SCENARIO_TO_ACRONYM[scenarioA];
    const acronymB = SCENARIO_TO_ACRONYM[scenarioB];

    if (isMobile) {
      await mobileSettings.click();
    }

    await page
      .getByRole("tabpanel", { name: "Scenarios" })
      .getByTestId(SCENARIO_B_MENU_TESTID)
      .click();
    await page.getByLabel(scenarioB).click();

    if (isMobile) {
      await page.getByRole("button").first().click();
    }

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition, @typescript-eslint/restrict-template-expressions -- current code is more flexible in case of changes on SCENARIOS_OPTIONS
    const acronymAForTitle = acronymA ? ` (${acronymA})` : "";
    const acronymBForTitle = acronymB ? ` (${acronymB})` : "";

    const expectedGraphTitle = `${scenarioA + acronymAForTitle} VS ${scenarioB + acronymBForTitle}`;
    await expect(page.getByTestId(FOR_SCENARIOS_TESTID)).toHaveText(
      expectedGraphTitle,
    );

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- current code is more flexible in case of changes on SCENARIOS_OPTIONS
    const expectedDisplayValue = `${acronymA || scenarioA}VS${acronymB || scenarioB}`;
    await expect(page.getByTestId(DISPLAY_SELECT_TESTID)).toHaveText(
      expectedDisplayValue,
    );

    if (isMobile) {
      await mobileSettings.click();
    }

    await page.getByRole("button", { name: RESET_LABEL }).click();

    if (isMobile) {
      await page.getByRole("button").first().click();
    }

    await expect(page.getByTestId(FOR_SCENARIOS_TESTID)).toHaveText(
      `${scenarioA} (${acronymA})`,
    );

    await expect(page.getByTestId(DISPLAY_SELECT_TESTID)).toHaveText(
      `${acronymA} only`,
    );
  });
});

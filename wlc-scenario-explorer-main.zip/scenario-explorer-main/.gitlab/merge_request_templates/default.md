- [ ] Temporary work is removed (commented code, console logs, etc.).
- [ ] Tests have been added or updated when necessary.

# What is it?